package de.wecker.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalTime

val Orange = Color(0xFFFF9F0A)
val Grey = Color(0xFF8E8E93)
val CardBg = Color(0xFF1C1C1E)
val Green = Color(0xFF34C759)
val Red = Color(0xFFFF453A)

@Composable
fun WeckerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Orange, background = Color.Black, surface = Color.Black),
        content = content,
    )
}

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        val ask = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ask.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { WeckerTheme { App(tick.intValue) } }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue = tick.intValue + 1
    }
}

fun newId(): Int = (System.currentTimeMillis() % 1_000_000_000L).toInt() + 1

@Composable
fun App(tick: Int) {
    val ctx = LocalContext.current
    val alarms = remember { mutableStateListOf<Alarm>().apply { addAll(Store.load(ctx)) } }
    var editMode by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Alarm?>(null) }
    var isNew by remember { mutableStateOf(false) }

    LaunchedEffect(tick) {
        alarms.clear()
        alarms.addAll(Store.load(ctx))
    }

    fun upsert(a: Alarm) {
        val i = alarms.indexOfFirst { it.id == a.id }
        if (i >= 0) {
            alarms[i] = a
        } else {
            alarms.add(a)
        }
        alarms.sortWith(compareBy<Alarm>({ it.hour }, { it.minute }))
        Store.save(ctx, alarms.toList())
        Alarms.schedule(ctx, a)
    }

    fun remove(a: Alarm) {
        alarms.removeAll { it.id == a.id }
        Store.save(ctx, alarms.toList())
        Alarms.cancel(ctx, a.id)
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    if (editMode) "Fertig" else "Bearbeiten",
                    color = Orange,
                    fontSize = 17.sp,
                    modifier = Modifier.clickable { editMode = !editMode }.padding(8.dp),
                )
                Spacer(Modifier.weight(1f))
                Text(
                    "+",
                    color = Orange,
                    fontSize = 34.sp,
                    modifier = Modifier
                        .clickable {
                            val now = LocalTime.now()
                            isNew = true
                            editing = Alarm(newId(), now.hour, now.minute)
                        }
                        .padding(horizontal = 12.dp),
                )
            }
            Text(
                "Wecker",
                color = Color.White,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp),
            )
            Text(
                "Weitere Wecker",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 4.dp),
            )
            LazyColumn(Modifier.weight(1f).navigationBarsPadding()) {
                items(alarms, key = { it.id }) { a ->
                    AlarmRow(
                        a = a,
                        editMode = editMode,
                        onToggle = { on -> upsert(a.copy(enabled = on)) },
                        onOpen = {
                            isNew = false
                            editing = a
                        },
                        onDelete = { remove(a) },
                    )
                }
            }
        }

        editing?.let { e ->
            key(e.id) {
                Editor(
                    start = e,
                    isNew = isNew,
                    onSave = { s ->
                        upsert(s)
                        editing = null
                        Toast.makeText(ctx, inText(s), Toast.LENGTH_LONG).show()
                    },
                    onDelete = {
                        remove(e)
                        editing = null
                    },
                    onCancel = { editing = null },
                )
            }
        }
    }
}

@Composable
fun WeckerSwitch(on: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked = on,
        onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedTrackColor = Green,
            checkedThumbColor = Color.White,
            checkedBorderColor = Color.Transparent,
            uncheckedTrackColor = Color(0xFF39393D),
            uncheckedThumbColor = Color.White,
            uncheckedBorderColor = Color.Transparent,
        ),
    )
}

@Composable
fun MinusButton(onClick: () -> Unit) {
    Box(
        Modifier.size(24.dp).clip(CircleShape).background(Red).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(width = 12.dp, height = 2.dp).background(Color.White))
    }
}

@Composable
fun BigButton(text: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Line() {
    HorizontalDivider(color = Color(0xFF38383A), modifier = Modifier.padding(start = 16.dp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlarmRow(
    a: Alarm,
    editMode: Boolean,
    onToggle: (Boolean) -> Unit,
    onOpen: () -> Unit,
    onDelete: () -> Unit,
) {
    val state = rememberSwipeToDismissBoxState(confirmValueChange = { v ->
        if (v == SwipeToDismissBoxValue.EndToStart) {
            onDelete()
            true
        } else {
            false
        }
    })
    SwipeToDismissBox(
        state = state,
        enableDismissFromStartToEnd = false,
        backgroundContent = {
            Box(
                Modifier.fillMaxSize().background(Red).padding(end = 24.dp),
                contentAlignment = Alignment.CenterEnd,
            ) {
                Text("Löschen", color = Color.White, fontSize = 17.sp)
            }
        },
    ) {
        Column(Modifier.background(Color.Black)) {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (editMode) {
                    MinusButton(onDelete)
                    Spacer(Modifier.width(12.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        timeText(a),
                        color = if (a.enabled) Color.White else Grey,
                        fontSize = 52.sp,
                        fontWeight = FontWeight.Light,
                    )
                    Text(
                        a.label + (if (a.days.isEmpty()) "" else ", " + repeatText(a.days)),
                        color = if (a.enabled) Color.White else Grey,
                        fontSize = 16.sp,
                    )
                }
                if (editMode) {
                    Text("›", color = Grey, fontSize = 28.sp)
                } else {
                    WeckerSwitch(a.enabled, onToggle)
                }
            }
            Line()
        }
    }
}

@Composable
fun OptionRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Color.White, fontSize = 17.sp)
        Text(
            value,
            color = Grey,
            fontSize = 17.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f).padding(start = 12.dp),
        )
        Text("  ›", color = Grey, fontSize = 20.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Wheel(count: Int, value: Int, onChange: (Int) -> Unit, modifier: Modifier = Modifier) {
    // Oben sichtbares Element = Auswahl - 2 (5 Zeilen sichtbar, Auswahl in der Mitte)
    val state = rememberLazyListState(initialFirstVisibleItemIndex = count * 1000 + value - 2)
    val fling = rememberSnapFlingBehavior(state)
    LaunchedEffect(state.isScrollInProgress) {
        if (!state.isScrollInProgress) onChange((state.firstVisibleItemIndex + 2) % count)
    }
    LazyColumn(modifier.height(220.dp), state = state, flingBehavior = fling) {
        items(count * 2000) { i ->
            Box(Modifier.fillMaxWidth().height(44.dp), contentAlignment = Alignment.Center) {
                Text("%02d".format(i % count), color = Color.White, fontSize = 26.sp)
            }
        }
    }
}

@Composable
fun RepeatScreen(days: Set<Int>, onChange: (Set<Int>) -> Unit, onBack: () -> Unit) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp)) {
        Text(
            "‹ Zurück",
            color = Orange,
            fontSize = 17.sp,
            modifier = Modifier.align(Alignment.CenterStart).clickable(onClick = onBack),
        )
        Text(
            "Wiederholen",
            color = Color.White,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.Center),
        )
    }
    Spacer(Modifier.height(16.dp))
    Column(Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(12.dp)).background(CardBg).fillMaxWidth()) {
        DAYS_LONG.forEachIndexed { i, name ->
            val d = i + 1
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onChange(if (days.contains(d)) days - d else days + d) }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Jeden $name", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                if (days.contains(d)) Text("✓", color = Orange, fontSize = 18.sp)
            }
            if (i < 6) Line()
        }
    }
}

@Composable
fun Editor(
    start: Alarm,
    isNew: Boolean,
    onSave: (Alarm) -> Unit,
    onDelete: () -> Unit,
    onCancel: () -> Unit,
) {
    var a by remember { mutableStateOf(start) }
    var sub by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val u = r.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            a = a.copy(sound = u?.toString())
        }
    }
    val ctx = LocalContext.current
    val soundName = remember(a.sound) {
        val s = a.sound
        if (s == null) {
            "Standard"
        } else {
            try {
                RingtoneManager.getRingtone(ctx, Uri.parse(s)).getTitle(ctx)
            } catch (e: Exception) {
                "Eigener Ton"
            }
        }
    }

    BackHandler {
        if (sub) {
            sub = false
        } else {
            onCancel()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
    ) {
        if (sub) {
            RepeatScreen(a.days, { d -> a = a.copy(days = d) }, { sub = false })
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp)) {
                    Text(
                        "Abbrechen",
                        color = Orange,
                        fontSize = 17.sp,
                        modifier = Modifier.align(Alignment.CenterStart).clickable(onClick = onCancel),
                    )
                    Text(
                        if (isNew) "Wecker hinzufügen" else "Wecker",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.align(Alignment.Center),
                    )
                    Text(
                        "Sichern",
                        color = Orange,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .clickable { onSave(a.copy(enabled = true, label = a.label.ifBlank { "Wecker" })) },
                    )
                }

                Box(
                    Modifier.fillMaxWidth().height(220.dp).padding(horizontal = 40.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF2C2C2E)),
                    )
                    Row(Modifier.fillMaxSize()) {
                        Wheel(24, a.hour, { h -> a = a.copy(hour = h) }, Modifier.weight(1f))
                        Wheel(60, a.minute, { m -> a = a.copy(minute = m) }, Modifier.weight(1f))
                    }
                }

                Spacer(Modifier.height(16.dp))
                Column(
                    Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(12.dp)).background(CardBg).fillMaxWidth(),
                ) {
                    OptionRow("Wiederholen", repeatText(a.days)) { sub = true }
                    Line()
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Beschriftung", color = Color.White, fontSize = 17.sp)
                        BasicTextField(
                            value = a.label,
                            onValueChange = { t -> a = a.copy(label = t) },
                            singleLine = true,
                            textStyle = TextStyle(color = Grey, fontSize = 17.sp, textAlign = TextAlign.End),
                            cursorBrush = SolidColor(Orange),
                            modifier = Modifier.weight(1f).padding(start = 12.dp),
                        )
                    }
                    Line()
                    OptionRow("Ton", soundName) {
                        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                        val cur = a.sound
                        if (cur != null) i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(cur))
                        picker.launch(i)
                    }
                    Line()
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Schlummern", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                        WeckerSwitch(a.snooze) { on -> a = a.copy(snooze = on) }
                    }
                }

                if (!isNew) {
                    Spacer(Modifier.height(16.dp))
                    Box(
                        Modifier
                            .padding(horizontal = 16.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CardBg)
                            .clickable(onClick = onDelete)
                            .padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("Wecker löschen", color = Red, fontSize = 17.sp)
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
