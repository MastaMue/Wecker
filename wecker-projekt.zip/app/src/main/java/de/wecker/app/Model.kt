package de.wecker.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.time.Duration
import java.time.ZonedDateTime

data class Alarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String = "Wecker",
    val days: Set<Int> = emptySet(), // 1 = Montag ... 7 = Sonntag
    val sound: String? = null,
    val snooze: Boolean = true,
    val enabled: Boolean = true,
)

val DAYS_SHORT = listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")
val DAYS_LONG = listOf("Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag")

fun timeText(a: Alarm): String = "%02d:%02d".format(a.hour, a.minute)

fun repeatText(d: Set<Int>): String = when {
    d.isEmpty() -> "Nie"
    d.size == 7 -> "Jeden Tag"
    d == setOf(1, 2, 3, 4, 5) -> "Werktags"
    d == setOf(6, 7) -> "Am Wochenende"
    else -> d.sorted().joinToString(" ") { DAYS_SHORT[it - 1] }
}

fun inText(a: Alarm): String {
    val m = Duration.between(ZonedDateTime.now(), Alarms.next(a)).toMinutes() + 1
    val d = m / 1440
    val h = (m % 1440) / 60
    val mi = m % 60
    val parts = mutableListOf<String>()
    if (d > 0) parts.add(if (d == 1L) "1 Tag" else "$d Tage")
    if (h > 0) parts.add("$h Std.")
    if (mi > 0 || parts.isEmpty()) parts.add("$mi Min.")
    return "Wecker in " + parts.joinToString(", ")
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("alarms", Context.MODE_PRIVATE)

    fun load(c: Context): List<Alarm> {
        val arr = JSONArray(sp(c).getString("list", "[]") ?: "[]")
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Alarm(
                id = o.getInt("id"),
                hour = o.getInt("h"),
                minute = o.getInt("m"),
                label = o.getString("label"),
                days = o.getString("days").split(",").filter { s -> s.isNotEmpty() }.map { s -> s.toInt() }.toSet(),
                sound = if (o.isNull("sound")) null else o.getString("sound"),
                snooze = o.getBoolean("snooze"),
                enabled = o.getBoolean("on"),
            )
        }.sortedWith(compareBy<Alarm>({ it.hour }, { it.minute }))
    }

    fun save(c: Context, list: List<Alarm>) {
        val arr = JSONArray()
        for (a in list) {
            val o = JSONObject()
            o.put("id", a.id)
            o.put("h", a.hour)
            o.put("m", a.minute)
            o.put("label", a.label)
            o.put("days", a.days.sorted().joinToString(","))
            o.put("sound", a.sound ?: JSONObject.NULL)
            o.put("snooze", a.snooze)
            o.put("on", a.enabled)
            arr.put(o)
        }
        sp(c).edit().putString("list", arr.toString()).apply()
    }
}

object Alarms {
    /** Nächster Klingelzeitpunkt nach [after]. */
    fun next(a: Alarm, after: ZonedDateTime = ZonedDateTime.now()): ZonedDateTime {
        for (i in 0..7) {
            val d = after.toLocalDate().plusDays(i.toLong())
            val t = d.atTime(a.hour, a.minute).atZone(after.zone)
            val dayOk = a.days.isEmpty() || a.days.contains(d.dayOfWeek.value)
            if (t.isAfter(after) && dayOk) return t
        }
        return after.plusDays(1)
    }

    private fun am(c: Context): AlarmManager = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun op(c: Context, id: Int, snooze: Boolean): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).putExtra("id", id).putExtra("snooze", snooze)
        return PendingIntent.getBroadcast(
            c,
            if (snooze) -id else id,
            i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun show(c: Context): PendingIntent =
        PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    fun schedule(c: Context, a: Alarm, after: ZonedDateTime = ZonedDateTime.now()) {
        cancel(c, a.id)
        if (!a.enabled) return
        val t = next(a, after).toInstant().toEpochMilli()
        am(c).setAlarmClock(AlarmManager.AlarmClockInfo(t, show(c)), op(c, a.id, false))
    }

    fun cancel(c: Context, id: Int) {
        am(c).cancel(op(c, id, false))
        am(c).cancel(op(c, id, true))
    }

    fun snooze(c: Context, id: Int) {
        val t = System.currentTimeMillis() + 9 * 60_000L
        am(c).setAlarmClock(AlarmManager.AlarmClockInfo(t, show(c)), op(c, id, true))
    }

    fun rescheduleAll(c: Context) {
        for (a in Store.load(c)) schedule(c, a)
    }

    /** Wird beim Klingeln aufgerufen: einmalige Wecker ausschalten, wiederholende neu planen. */
    fun fired(c: Context, id: Int) {
        val list = Store.load(c).toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return
        val a = list[idx]
        if (a.days.isEmpty()) {
            list[idx] = a.copy(enabled = false)
            Store.save(c, list)
        } else {
            schedule(c, a, ZonedDateTime.now().plusSeconds(5))
        }
    }
}
