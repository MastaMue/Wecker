package de.wecker.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class AlarmService : Service() {
    companion object {
        const val DISMISS = "de.wecker.app.DISMISS"
    }

    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getIntExtra("id", 0) ?: 0
        val action = intent?.action
        if (action == "STOP") {
            stopAll()
            return START_NOT_STICKY
        }
        if (action == "SNOOZE") {
            Alarms.snooze(this, id)
            stopAll()
            return START_NOT_STICKY
        }
        val a = Store.load(this).firstOrNull { it.id == id }
        startForeground(1, buildNotification(id, a), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        if (a == null) {
            stopAll()
            return START_NOT_STICKY
        }
        ring(a)
        return START_NOT_STICKY
    }

    private fun buildNotification(id: Int, a: Alarm?): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel("alarm", "Wecker", NotificationManager.IMPORTANCE_HIGH)
        channel.setSound(null, null)
        nm.createNotificationChannel(channel)

        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, RingActivity::class.java).putExtra("id", id), flags
        )
        fun act(code: Int, action: String): PendingIntent = PendingIntent.getService(
            this, code, Intent(this, AlarmService::class.java).setAction(action).putExtra("id", id), flags
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_alarm)

        val b = Notification.Builder(this, "alarm")
            .setSmallIcon(R.drawable.ic_alarm)
            .setContentTitle(a?.label ?: "Wecker")
            .setContentText(if (a != null) timeText(a) else "")
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
        if (a?.snooze == true) {
            b.addAction(Notification.Action.Builder(icon, "Schlummern", act(3, "SNOOZE")).build())
        }
        b.addAction(Notification.Action.Builder(icon, "Stopp", act(2, "STOP")).build())
        return b.build()
    }

    private fun vib(): Vibrator =
        (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator

    private fun ring(a: Alarm) {
        stopSound()
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val uris = listOfNotNull(
            a.sound?.let { Uri.parse(it) },
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
        )
        for (u in uris) {
            val mp = MediaPlayer()
            try {
                mp.setAudioAttributes(attrs)
                mp.setDataSource(this, u)
                mp.isLooping = true
                mp.prepare()
                mp.start()
                player = mp
                break
            } catch (e: Exception) {
                mp.release()
            }
        }
        vib().vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0), attrs)
        handler.postDelayed({ stopAll() }, 15 * 60_000L)
    }

    private fun stopSound() {
        handler.removeCallbacksAndMessages(null)
        val p = player
        player = null
        if (p != null) {
            try {
                p.stop()
            } catch (e: Exception) {
            }
            p.release()
        }
        vib().cancel()
    }

    private fun stopAll() {
        stopSound()
        sendBroadcast(Intent(DISMISS).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopSound()
        super.onDestroy()
    }
}
