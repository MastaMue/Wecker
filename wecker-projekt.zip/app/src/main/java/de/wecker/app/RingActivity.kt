package de.wecker.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background

class RingActivity : ComponentActivity() {
    private val dismiss = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            this@RingActivity.finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        registerReceiver(dismiss, IntentFilter(AlarmService.DISMISS), RECEIVER_NOT_EXPORTED)

        val id = intent.getIntExtra("id", 0)
        val alarm = Store.load(this).firstOrNull { it.id == id }
        setContent {
            WeckerTheme {
                RingScreen(
                    alarm,
                    onSnooze = { send("SNOOZE", id) },
                    onStop = { send("STOP", id) },
                )
            }
        }
    }

    private fun send(action: String, id: Int) {
        startService(Intent(this, AlarmService::class.java).setAction(action).putExtra("id", id))
        finish()
    }

    override fun onDestroy() {
        unregisterReceiver(dismiss)
        super.onDestroy()
    }
}

@Composable
fun RingScreen(a: Alarm?, onSnooze: () -> Unit, onStop: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .systemBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.weight(1f))
        Text(
            if (a != null) timeText(a) else "",
            color = Color.White,
            fontSize = 84.sp,
            fontWeight = FontWeight.Light,
        )
        Text(a?.label ?: "Wecker", color = Orange, fontSize = 24.sp)
        Spacer(Modifier.weight(1f))
        if (a?.snooze == true) {
            BigButton("Schlummern", Color(0xFF3A3A3C), Color.White, onSnooze)
            Spacer(Modifier.height(12.dp))
        }
        BigButton("Stopp", Orange, Color.Black, onStop)
    }
}
